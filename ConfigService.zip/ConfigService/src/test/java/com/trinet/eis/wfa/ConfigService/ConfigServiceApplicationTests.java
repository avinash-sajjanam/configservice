package com.trinet.eis.wfa.ConfigService;

import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.AnnotationConfigContextLoader;
import org.springframework.test.context.web.WebAppConfiguration;

import com.trinet.eis.wfa.ConfigService.controller.ConfigController;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes={ConfigServiceApplication.class,ConfigController.class})
@ContextConfiguration(classes = ConfigServiceApplication.class, loader = AnnotationConfigContextLoader.class)
@WebAppConfiguration
public abstract class ConfigServiceApplicationTests {
	

}
