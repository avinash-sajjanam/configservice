package com.trinet.eis.wfa.ConfigService;

import java.io.IOException;

import org.apache.commons.io.IOUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.trinet.eis.wfa.ConfigService.controller.ConfigController;

@RunWith(SpringRunner.class)
@WebMvcTest(ConfigController.class)
public class ConfigControllerTest{

	@MockBean
	private  MongoTemplate mongoTemplate;
	
	@Autowired
	private MockMvc mockMvc;

//	@Before
//	public void setUp() throws Exception {
//		mockMvc = MockMvcBuilders.webAppContextSetup(context).build();
//	}

	@Test
	public void getConfigTest() throws Exception {
		MongoTemplate mongoTemplate= Mockito.mock(MongoTemplate.class);
		Mockito.when(mongoTemplate.findById(Mockito.anyString(), Mockito.any(), Mockito.anyString())).thenReturn(getConfigurations());
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/config/id/0004")
				.accept(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		JSONAssert.assertEquals(getConfigurations(), result.getResponse().toString(), false);
	}
	private String getConfigurations() throws IOException{
		return IOUtils.toString(this.getClass().getResourceAsStream("/test.json"), "UTF-8");
	}

	//@Test
	//public void post
}
