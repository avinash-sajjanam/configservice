package com.trinet.eis.wfa.ConfigService.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.trinet.eis.wfa.ConfigService.dao.ConfigObjects;

public interface ConfigRepository extends MongoRepository<ConfigObjects, String>{

}
