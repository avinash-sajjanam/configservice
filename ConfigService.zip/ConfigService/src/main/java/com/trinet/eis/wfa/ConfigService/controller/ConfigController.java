package com.trinet.eis.wfa.ConfigService.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mongodb.DBObject;
import com.mongodb.util.JSON;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@Api(value="Configuration Service")
@RequestMapping("/config")
public class ConfigController {
	
	
	@Autowired
	private MongoTemplate mongoTemplate;

	
	@ApiOperation(value="Save Configuration object")
	@RequestMapping(value = "/", method = RequestMethod.POST)
	public void ConfigObjString(@RequestBody String jsonPayload) throws Exception{		
		DBObject dbObject = (DBObject) JSON.parse(jsonPayload);
		mongoTemplate.save(dbObject,"ConfigObjects");
	}
	
	@ApiOperation(value="get configuration object by id/index")
	@RequestMapping(value = "/id/{id}", method = RequestMethod.GET)
	DBObject getObj(@PathVariable("id")String id){
		DBObject obj= mongoTemplate.findById(id,DBObject.class, "ConfigObjects");
		return obj;
		}
	
/*	@ApiOperation(value="Get all configuration objects")
	@RequestMapping(value = "/", method = RequestMethod.GET)
	List<DBObject> getConfig(){
		List<DBObject> objs=mongoTemplate.findAll(DBObject.class, "ConfigObjects");
		return objs;
	}*/
	
}
