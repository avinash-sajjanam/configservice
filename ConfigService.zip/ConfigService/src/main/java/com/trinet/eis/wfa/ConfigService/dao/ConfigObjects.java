package com.trinet.eis.wfa.ConfigService.dao;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection="ConfigObjects")
public class ConfigObjects {
	
	@Id
	@Field("_id")
	private String id;
	
	private Object object;
	
	public ConfigObjects(){
		
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Object getObject() {
		return object;
	}

	public void setObject(Object object) {
		this.object = object;
	}

}
